#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from google.colab import drive
drive.mount('/content/drive')


# In[ ]:


cd 'drive/My Drive/SpineDetection'


# In[ ]:


import numpy as np
from os import listdir,path
import cv2
import random


# In[ ]:


import matplotlib.pyplot as plt
import matplotlib.image as mpimg
get_ipython().run_line_magic('matplotlib', 'inline')


# In[ ]:


path = './Damaged/'
allDam = listdir(path)
print("Damaged are indexed b/w 0 to", len(allDam)-1 )
for fold in allDam:
    img = cv2.imread(path + fold + '/AP/Ap_Pedicle.png')
    allImgs.append((img[:,:, 0]).shape)

path = './Normal/'
allNor = listdir(path)
print("Damaged are indexed b/w", len(allDam), "to", len(allNor) + len(allDam)-1 )
for fold in allNor:
    img = cv2.imread(path + fold + '/AP/Ap_Pedicle.png')
    allImgs.append((img[:,:, 0]).shape)


# In[ ]:


total_points = len(listdir('./Damaged/')) + len(listdir('./Normal/'))
total_points


# In[ ]:


#list of all features
AP = ['Ap_Pedicle.png', 'Ap_Spinous_Process.png', 'Ap_Vertebra.png']


# In[ ]:


#creating data
final = np.array([[] for i in range(total_points)])

AllImgs = []
feature = 'Ap_Spinous_Process.png'
path = './Damaged/'
allDam = listdir(path)
for fold in allDam:
    img = cv2.imread(path + fold + '/AP/' + feature)
    print(fold)
    im1 = img[:,:, 0]
    imrs = cv2.resize(im1, (512,512), interpolation = cv2.INTER_AREA)
    AllImgs.append(imrs)

path = './Normal/'
allNor = listdir(path)
for fold in allNor:
    img = cv2.imread(path + fold + '/AP/' + feature)
    print(fold)
    im1 = img[:,:, 0]
    imrs = cv2.resize(im1, (512,512), interpolation = cv2.INTER_AREA)
    AllImgs.append(imrs)

data = np.array(AllImgs)
data1 = data.astype('float32')
data1 = data1/255
data1.shape


# In[ ]:


np.save('all data matrixs/Ap_Spinous_Processdata1.npy', data1)


# In[ ]:


data1 = np.load('all data matrixs/Ap_Spinous_Processdata1.npy')


# In[ ]:


# 0 represent Damaged & 1 represents Normal
l1 = np.array([0 for i in range(len(listdir('./Damaged/')))])
l2 = np.array([1 for i in range(len(listdir('./Normal/')))])
yunsuff = np.append(l1, l2)


# In[ ]:


#data resuffuling to create validation split
mapping = np.arange(total_points)
random.shuffle(mapping)

y = np.array([yunsuff[mapping[i]] for i in range(total_points)])
data2 = np.array([data1[mapping[i]] for i in range(total_points)])
data2.shape


# In[ ]:


data = data2.reshape((data2.shape[0], 512,512, 1))
data.shape


# In[ ]:


from keras.models import Sequential
from keras.layers import Conv2D, Dense, BatchNormalization, Dropout, Flatten, MaxPooling2D
from keras.optimizers import SGD, Adam
from keras.utils import to_categorical


# In[ ]:


model = Sequential()
model.add(Conv2D(32, kernel_size = (3, 3), padding="same",activation='relu', input_shape=(512,512, 1)))
model.add(MaxPooling2D(pool_size=(2,2)))
model.add(BatchNormalization())
model.add(Conv2D(64, kernel_size=(3,3), padding="same",activation='relu'))
model.add(MaxPooling2D(pool_size=(2,2)))
model.add(BatchNormalization())
model.add(Conv2D(64, kernel_size=(3,3), padding="same",activation='relu'))
model.add(MaxPooling2D(pool_size=(2,2)))
model.add(BatchNormalization())
model.add(Conv2D(96, kernel_size=(3,3), padding="same",activation='relu'))
model.add(MaxPooling2D(pool_size=(2,2)))
model.add(BatchNormalization())
model.add(Conv2D(128, kernel_size=(3,3), padding="same", activation='relu'))
model.add(MaxPooling2D(pool_size=(2,2)))
model.add(BatchNormalization())
model.add(Dropout(0.2))
model.add(Flatten())
model.add(Dense(256, activation='relu'))
#model.add(Dropout(0.3))
model.add(Dense(1, activation = 'sigmoid'))

opt = SGD(lr = 0.01, momentum = 0.9)
model.compile(optimizer=opt, loss='binary_crossentropy',metrics=['accuracy'])


# In[ ]:


model.summary()


# In[ ]:


#train-test split
train_x  = data[50:]
test_x = data[:50]
train_y = y[50:]
test_y = y[:50]


# In[ ]:


train_x.shape


# In[ ]:


model.fit(train_x, train_y, batch_size=32, epochs=20, verbose = 1, validation_split= 0.2)


# In[ ]:


model.fit(train_x, train_y, batch_size=32, epochs=10, verbose = 1, validation_split= 0.0)


# In[ ]:


loss, acc = model.evaluate(test_x, test_y, verbose  = 0)
print(acc * 100)


# In[ ]:




