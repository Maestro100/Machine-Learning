# -*- coding: utf-8 -*-
"""
Created on Wed Feb 19 06:31:37 2020

@author: jasleena
"""

import os
import numpy as np
import torch
from PIL import Image

from readXray import *
from torchvision import transforms, utils

import transforms as T
from utils import *


print ('AP_index in new file:', AP_index)

def get_transform(train):
    transforms = []
    transforms.append(T.ToTensor())
    if train:
        transforms.append(T.RandomHorizontalFlip(0.5))
    return T.Compose(transforms)


class PennFudanDataset(object):
    def __init__(self,  AP_index_list, transforms):
        
        self.imgs_id = AP_index_list
        self.transforms = transforms
        # load all image files, sorting them to
        # ensure that they are aligned
        #self.imgs = list(sorted(os.listdir(os.path.join(root, "PNGImages"))))
        #self.masks = list(sorted(os.listdir(os.path.join(root, "PedMasks"))))

    def __getitem__(self, iditer):
        # load images ad masks
        idx = self.imgs_id[iditer]
        
        img_path = makeNormalAPpath(idx)
        mask_path = makeNormalAPvertebrapath(idx) 
             
        
        #img = Image.open(img_path).convert("RGB")
        img = Image.open(img_path)
        img = img.resize((1024,1024),Image.ANTIALIAS)
        # note that we haven't converted the mask to RGB,
        # because each color corresponds to a different instance
        # with 0 being background
        mask = Image.open(mask_path)
        mask = mask.resize((1024,1024),Image.ANTIALIAS)
        # convert the PIL Image into a numpy array
        mask = np.array(mask)
        # instances are encoded as different colors
        obj_ids = np.unique(mask) #obj ids: [False  True]        
        
        # first id is the background, so remove it
        obj_ids = obj_ids[1:]

        # split the color-encoded mask into a set
        # of binary masks
        masks = mask == obj_ids[:, None, None]

        # get bounding box coordinates for each mask
        num_objs = len(obj_ids)
        boxes = []
        for i in range(num_objs):
            pos = np.where(masks[i])
            xmin = np.min(pos[1])
            xmax = np.max(pos[1])
            ymin = np.min(pos[0])
            ymax = np.max(pos[0])
            boxes.append([xmin, ymin, xmax, ymax])

        # convert everything into a torch.Tensor
        boxes = torch.as_tensor(boxes, dtype=torch.float32)
        # there is only one class
        labels = torch.ones((num_objs,), dtype=torch.int64)
        masks = torch.as_tensor(masks, dtype=torch.uint8)

        image_id = torch.tensor([idx])
        area = (boxes[:, 3] - boxes[:, 1]) * (boxes[:, 2] - boxes[:, 0])
        # suppose all instances are not crowd
        iscrowd = torch.zeros((num_objs,), dtype=torch.int64)

        target = {}
        target["boxes"] = boxes
        target["labels"] = labels
        target["masks"] = masks
        target["image_id"] = image_id
        target["area"] = area
        target["iscrowd"] = iscrowd   
        
        if self.transforms is not None:
            img, target = self.transforms(img, target)
        
       # img = T.ToTensor()(img).unsqueeze(0)
        
       # Target mask shape: torch.Size([1, 2792, 1937])
       # Target boxes shape: torch.Size([1, 4])
       # Target area shape: torch.Size([1])
       
        return img, target
    
    def myfunc(self, iditer):
        # load images ad masks
        idx = self.imgs_id[iditer]
        print ("Inside getitem idx:", idx)
        img_path = makeNormalAPpath(idx)
        mask_path = makeNormalAPvertebrapath(idx)
        
        print ('img_path:', img_path)
        print ('mask_path:', mask_path)        
        
        #img = Image.open(img_path).convert("RGB")
        img = Image.open(img_path)
        img = img.resize((1024,1024),Image.ANTIALIAS)
        #img = resizeImage(img)
        plt.imshow(img)
        # note that we haven't converted the mask to RGB,
        # because each color corresponds to a different instance
        # with 0 being background
        mask = Image.open(mask_path)
        mask = mask.resize((1024,1024),Image.ANTIALIAS)
        #mask = resizeImage(mask)
       
        # convert the PIL Image into a numpy array
        mask = np.array(mask)
        print ('MASK SHAPE:', mask.shape)
        # instances are encoded as different colors
        obj_ids = np.unique(mask) #obj ids: [False  True]
        print ("obj ids:", obj_ids)
        
        # first id is the background, so remove it
        obj_ids = obj_ids[1:]

        # split the color-encoded mask into a set
        # of binary masks
        masks = mask == obj_ids[:, None, None]

        # get bounding box coordinates for each mask
        num_objs = len(obj_ids)
        boxes = []
        for i in range(num_objs):
            pos = np.where(masks[i])
            xmin = np.min(pos[1])
            xmax = np.max(pos[1])
            ymin = np.min(pos[0])
            ymax = np.max(pos[0])
            boxes.append([xmin, ymin, xmax, ymax])

        # convert everything into a torch.Tensor
        boxes = torch.as_tensor(boxes, dtype=torch.float32)
        # there is only one class
        labels = torch.ones((num_objs,), dtype=torch.int64)
        masks = torch.as_tensor(masks, dtype=torch.uint8)

        image_id = torch.tensor([idx])
        area = (boxes[:, 3] - boxes[:, 1]) * (boxes[:, 2] - boxes[:, 0])
        # suppose all instances are not crowd
        iscrowd = torch.zeros((num_objs,), dtype=torch.int64)

        target = {}
        target["boxes"] = boxes
        target["labels"] = labels
        target["masks"] = masks
        target["image_id"] = image_id
        target["area"] = area
        target["iscrowd"] = iscrowd
        
        print ("masks:", masks)
        print ("boxes:", boxes)

        print ('img before transformation:', img)     
        tempimgnp = np.array(img) #to be deleted
        print ('Img shape', tempimgnp.shape) #Img shape (2792, 1937, 3) Mask shape : MASK SHAPE: (2792, 1937)
       
        if self.transforms is not None:
            img, target = self.transforms(img, target)

        print ('img after:', img)
                
        print ("Img returned:", img)
        print ("Target returned:", target)
        print ("Target mask shape:", target["masks"].shape)
        print ("Target boxes shape:", target["boxes"].shape)
        print ("Target area shape:", target["area"].shape)
        
       # Target mask shape: torch.Size([1, 2792, 1937])
       # Target boxes shape: torch.Size([1, 4])
       # Target area shape: torch.Size([1])
       
        return img, target


    def __len__(self):
        #return 1
        return len(self.imgs_id) 
    
