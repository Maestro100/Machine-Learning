#!/usr/bin/env python
# coding: utf-8

# In[4]:


import numpy as np
import cv2
from os import listdir,path


# In[5]:


import matplotlib.pyplot as plt
import matplotlib.image as mpimg
get_ipython().run_line_magic('matplotlib', 'inline')


# In[50]:


path = "./Damaged/ID (58)/"


# In[60]:


image = cv2.imread(path + "AP/AP.jpg")
image2 = cv2.imread(path + "LAT/LAT.jpg")


# In[52]:


np.unique(image[:, :, 2] == image[:, :, 0])


# In[53]:


plt.imshow(image)


# In[76]:


tmp = image[:,:,0]
nwg = tmp.reshape((tmp.shape[0],tmp.shape[1], 1))
tmp2 = image2[:,:,0]
nwg2 = tmp2.reshape((tmp2.shape[0],tmp2.shape[1], 1))
nwg2.shape


# In[71]:


hyb = np.append(image[:, :, 0], image2[:, :, 0], axis =0)
hyb.shape


# In[72]:


plt.imshow(hyb)


# In[58]:


im1 = image[:, :, 0]
print(im1.shape)
im2  = cv2.resize(im1, (512, 1024), interpolation = cv2.INTER_AREA)
plt.imshow(im2)


# In[78]:


#Checking for both Normal & Damaged
path = './TestData/'
allfold = listdir(path)


# In[82]:


sizes = []
for fold in allfold:
    pth = path + fold
    allimg = listdir(pth + '/AP')
    if ("AP.jpg" not in allimg):
        print(fold)


# In[43]:





# In[8]:


sizes


# In[6]:


#image size analysis
imsize = []
for fold in allfold:
    img = cv2.imread(path + fold + '/LAT/Lat_Pedicle.png')
    imsize.append(list(img.shape))


# In[13]:


imsize = np.array(imsize)


# In[23]:


now = imsize[:, 0]
plt.hist(now, bins = range(np.min(now), np.max(now)) )
plt.show()


# In[22]:


now = imsize[:, 1]
plt.hist(now, bins = range(np.min(now), np.max(now)) )
plt.show()


# In[31]:


now =imsize[:, 1]
np.size(now)

