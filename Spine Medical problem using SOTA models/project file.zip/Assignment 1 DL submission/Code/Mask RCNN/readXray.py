# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 10:34:51 2020

@author: jasleena
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Feb 15 22:49:47 2020

@author: jasleena
"""
import os
import numpy as np
from skimage import io
import cv2
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
from PIL import Image
from resizeimage import resizeimage


AP_index = []
AP_vertebra_index = []    
dir_path = 'D:\\Work\\ELL888_advance_machine_learning\\Assignment1'

def makeNormalAPpath(id) :
   
   dbpath = dir_path+"\Training"
   normalPath = os.path.join(dbpath,'Normal')
   damagedPath = os.path.join(dbpath,'Damaged')
   print ('Normal Path:', normalPath)
   print ('Damaged Path:', damagedPath)
   idstr = 'ID (' + str(id) + ')'
   AP_PATH = os.path.join(normalPath,idstr)
   #AP_PATH = os.path.join(AP_PATH,'AP')
   AP_PATH = os.path.join(AP_PATH,'LAT')
   AP_PATH = os.path.join(AP_PATH,'LAT.jpg')
   print ('AP PATH', AP_PATH)
   return AP_PATH

def makeNormalAPvertebrapath(id) :
   
   dbpath = dir_path+"\Training"
   normalPath = os.path.join(dbpath,'Normal')
   damagedPath = os.path.join(dbpath,'Damaged')
   print ('Normal Path:', normalPath)
   print ('Damaged Path:', damagedPath)
   idstr = 'ID (' + str(id) + ')'
   AP_PATH = os.path.join(normalPath,idstr)
   #AP_PATH = os.path.join(AP_PATH,'AP')
   AP_PATH = os.path.join(AP_PATH,'LAT')
   AP_PATH = os.path.join(AP_PATH,'LAT_Vertebra.png')
   print ('AP PATH', AP_PATH)
   return AP_PATH

def extractID (test_string) :
    res1 = test_string.split('(')
    #print ("after split:", res1)
    res2 = res1[1].split(')')
    #print ('ID:', res2[0])
    ID = res2[0]
    ID = int(ID)
    return ID
    
def resizeImage (img):
    cover = resizeimage.resize_cover(img, [1024, 1024])
    return cover
    

def resizeImageCV2 (img): #img is numpy
    res = cv2.resize(img, dsize=(1024, 1024), interpolation=cv2.INTER_CUBIC)
   
    return res




def updateAPindex (AP_PATH,id) :
    APimgpath = os.path.join(AP_PATH,'AP.jpg')
    if (os.path.exists(APimgpath)):
        AP_index.append(id)
    return
    
def update_AP_Vertebra_index (AP_PATH,id) :
    AP_vertebraPath = os.path.join(AP_PATH,'AP_Vertebra.png')
    #print ('AP_vertebraPath:', AP_vertebraPath)
    if (os.path.exists(AP_vertebraPath)):          
        AP_vertebra_index.append(id)
        
    return
    
def readDatabaseID() :
    
   
   dbpath = dir_path+"\Training"
   normalPath = os.path.join(dbpath,'Normal')
   damagedPath = os.path.join(dbpath,'Damaged')
   print ('Normal Path:', normalPath)
   print ('Damaged Path:', damagedPath)
   image_count = 0 
   normalFolders = [f for f in os.listdir(normalPath) if os.path.isdir(os.path.join(normalPath, f))]
   
   for f in normalFolders:
      print (f)
      id = extractID(f)
      AP_PATH = os.path.join(normalPath,f,'AP')
      
      updateAPindex(AP_PATH,id)
      update_AP_Vertebra_index(AP_PATH,id)
      
      image_count = image_count + 1
#      if (image_count == 6):
#            print ('AP_vertebra_index : ', AP_vertebra_index)
#            print ('AP_index : ', AP_index)            
#            break  
         
   return    
        
readDatabaseID()        
   

        

